import './App.css';
import Display from './Display.js';
import Graph from './Graph.js';
import Home from "./home.js"
import Login from './Login.js';
import NewData from './NewData.js';
import Register from './Register';
import { BrowserRouter, Routes,Route } from 'react-router-dom';

function App() {
   return(
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />
      <Route path="/display" element={<Display />} />
      <Route path='/edit' element={<NewData />} />
      <Route path='/graph' element={<Graph />} />
    </Routes>
  </BrowserRouter>
   );
  
}
export default App;
